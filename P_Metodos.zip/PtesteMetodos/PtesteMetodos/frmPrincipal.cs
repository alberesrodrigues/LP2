﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void cópiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chamou Cópiar");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chamou Colar");
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Verifica se o form2 foi aberto
            if (Application.OpenForms.OfType<frmExercicio2>().Count() > 0)
            {
                // Chama o Form frmExercicio2 para a frente
                Application.OpenForms["frmExercicio2"].BringToFront(); 
            }
            else
            {
                frmExercicio2 objfrm2 = new frmExercicio2();
                objfrm2.MdiParent = this; // Deixa o form2 ancorado no form1
                objfrm2.WindowState = FormWindowState.Maximized;
                objfrm2.Show();
            }
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Verifica se o form3 foi aberto
            if (Application.OpenForms.OfType<frmExercicio3>().Count() > 0)
            {
                // Chama o Form frmExercicio3 para a frente
                Application.OpenForms["frmExercicio3"].BringToFront();
            }
            else
            {
                frmExercicio3 objfrm3 = new frmExercicio3();
                objfrm3.MdiParent = this; // Deixa o form3 ancorado no form1
                objfrm3.WindowState = FormWindowState.Maximized;
                objfrm3.Show();
            }
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Verifica se o form4 foi aberto
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                // Chama o Form frmExercicio4 para a frente
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 objfrm4 = new frmExercicio4();
                objfrm4.MdiParent = this; // Deixa o form4 ancorado no form1
                objfrm4.WindowState = FormWindowState.Maximized;
                objfrm4.Show();
            }
        }

        private void exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Verifica se o form5 foi aberto
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                // Chama o Form frmExercicio5 para a frente
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 objfrm5 = new frmExercicio5();
                objfrm5.MdiParent = this; // Deixa o form5 ancorado no form1
                objfrm5.WindowState = FormWindowState.Maximized;
                objfrm5.Show();
            }
        }
    }
}
