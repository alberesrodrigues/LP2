﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class fmrMensalista : Form
    {
        public fmrMensalista()
        {
            InitializeComponent();
        }

        private void btn_EstanciaMensalista_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            objMensalista.NomeEmpregado = txt_Nome.Text;
            objMensalista.Matricula = Convert.ToInt32(txt_Matricula.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txt_DataEntrada.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txt_SalarioMensal.Text);

            MessageBox.Show($"Nome=  {objMensalista.NomeEmpregado} \n" +
                $"Matricula= {objMensalista.Matricula} \n" +
                $"Tempo Trabalho: {objMensalista.TempoTrabalho()}\n" +
                $"Salario final = {objMensalista.SalarioBruto().ToString("N2")}");

            MessageBox.Show(Mensalista.Empresa);
            MessageBox.Show(Mensalista.Filial);
        
        }

        private void btnInsComParametros_Click(object sender, EventArgs e)
        {
            Mensalista ObjMensalista = new Mensalista
                (
                Convert.ToInt32(txt_Matricula.Text),
                txt_Nome.Text,
                Convert.ToDateTime(txt_DataEntrada.Text),
                Convert.ToDouble(txt_SalarioMensal.Text)
                );

            MessageBox.Show($"Nome: {ObjMensalista.NomeEmpregado} \n" +
                $"Matricula: {ObjMensalista.Matricula} \n" +
                $"Tempo Trabalho: {ObjMensalista.TempoTrabalho()}\n" +
                $"Salario final: {ObjMensalista.SalarioBruto().ToString("N2")}");
        }
    }
}
