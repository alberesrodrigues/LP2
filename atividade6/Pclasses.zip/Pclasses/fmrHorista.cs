﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class fmrHorista : Form
    {
        public fmrHorista()
        {
            InitializeComponent();
        }

        private void btn_EstanciarHorista_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            objHorista.NomeEmpregado = txt_Nome.Text;
            objHorista.Matricula = Convert.ToInt32(txt_Matricula.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txt_DataEntrada.Text);
            objHorista.SalarioHora = Convert.ToDouble(txt_SalarioPorHora.Text);
            objHorista.NumeroHora = Convert.ToInt32(txt_NumeroDeHoras.Text);
            objHorista.DiasFalta = Convert.ToInt32(txt_DiasDeFaltas.Text);

            MessageBox.Show($"Nome: {objHorista.NomeEmpregado} \n" +
                $"Matricula: {objHorista.Matricula} \n" +
                $"Tempo Trabalho: {objHorista.TempoTrabalho()}\n" +
                $"Salario final: {objHorista.SalarioBruto().ToString("N2")}");
        }
    }
}
