﻿namespace Pclasses
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Mesalista = new System.Windows.Forms.Button();
            this.btn_Horista = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Mesalista
            // 
            this.btn_Mesalista.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Mesalista.Location = new System.Drawing.Point(93, 84);
            this.btn_Mesalista.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Mesalista.Name = "btn_Mesalista";
            this.btn_Mesalista.Size = new System.Drawing.Size(168, 85);
            this.btn_Mesalista.TabIndex = 0;
            this.btn_Mesalista.Text = "Mensalista";
            this.btn_Mesalista.UseVisualStyleBackColor = true;
            this.btn_Mesalista.Click += new System.EventHandler(this.btn_Mesalista_Click);
            // 
            // btn_Horista
            // 
            this.btn_Horista.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Horista.Location = new System.Drawing.Point(309, 84);
            this.btn_Horista.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Horista.Name = "btn_Horista";
            this.btn_Horista.Size = new System.Drawing.Size(164, 85);
            this.btn_Horista.TabIndex = 1;
            this.btn_Horista.Text = "Horista";
            this.btn_Horista.UseVisualStyleBackColor = true;
            this.btn_Horista.Click += new System.EventHandler(this.btn_Horista_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(133, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(323, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "CADASTRO DE FUNCIONÁRIO";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(590, 237);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Horista);
            this.Controls.Add(this.btn_Mesalista);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Mesalista;
        private System.Windows.Forms.Button btn_Horista;
        private System.Windows.Forms.Label label1;
    }
}

