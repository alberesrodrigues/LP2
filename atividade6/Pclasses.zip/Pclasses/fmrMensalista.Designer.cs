﻿namespace Pclasses
{
    partial class fmrMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_Matricula = new System.Windows.Forms.TextBox();
            this.txt_Nome = new System.Windows.Forms.TextBox();
            this.txt_SalarioMensal = new System.Windows.Forms.TextBox();
            this.txt_DataEntrada = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_EstanciaMensalista = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btnInsComParametros = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_Matricula
            // 
            this.txt_Matricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Matricula.Location = new System.Drawing.Point(334, 98);
            this.txt_Matricula.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_Matricula.Name = "txt_Matricula";
            this.txt_Matricula.Size = new System.Drawing.Size(216, 32);
            this.txt_Matricula.TabIndex = 6;
            // 
            // txt_Nome
            // 
            this.txt_Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Nome.Location = new System.Drawing.Point(334, 159);
            this.txt_Nome.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_Nome.Name = "txt_Nome";
            this.txt_Nome.Size = new System.Drawing.Size(216, 32);
            this.txt_Nome.TabIndex = 7;
            // 
            // txt_SalarioMensal
            // 
            this.txt_SalarioMensal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SalarioMensal.Location = new System.Drawing.Point(334, 219);
            this.txt_SalarioMensal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_SalarioMensal.Name = "txt_SalarioMensal";
            this.txt_SalarioMensal.Size = new System.Drawing.Size(216, 32);
            this.txt_SalarioMensal.TabIndex = 8;
            // 
            // txt_DataEntrada
            // 
            this.txt_DataEntrada.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DataEntrada.Location = new System.Drawing.Point(334, 272);
            this.txt_DataEntrada.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_DataEntrada.Name = "txt_DataEntrada";
            this.txt_DataEntrada.Size = new System.Drawing.Size(216, 32);
            this.txt_DataEntrada.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(58, 99);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 26);
            this.label1.TabIndex = 2;
            this.label1.Text = "Matrícula";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(58, 156);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 26);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nome";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(58, 216);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 26);
            this.label3.TabIndex = 4;
            this.label3.Text = "Salário Mensal";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(58, 280);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(254, 26);
            this.label4.TabIndex = 5;
            this.label4.Text = "Data Entrada Empresa";
            // 
            // btn_EstanciaMensalista
            // 
            this.btn_EstanciaMensalista.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EstanciaMensalista.Location = new System.Drawing.Point(100, 359);
            this.btn_EstanciaMensalista.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_EstanciaMensalista.Name = "btn_EstanciaMensalista";
            this.btn_EstanciaMensalista.Size = new System.Drawing.Size(190, 62);
            this.btn_EstanciaMensalista.TabIndex = 11;
            this.btn_EstanciaMensalista.Text = "Estanciar Mensalista";
            this.btn_EstanciaMensalista.UseVisualStyleBackColor = true;
            this.btn_EstanciaMensalista.Click += new System.EventHandler(this.btn_EstanciaMensalista_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(214, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(174, 29);
            this.label5.TabIndex = 12;
            this.label5.Text = "MENSALISTA";
            // 
            // btnInsComParametros
            // 
            this.btnInsComParametros.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsComParametros.Location = new System.Drawing.Point(324, 342);
            this.btnInsComParametros.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnInsComParametros.Name = "btnInsComParametros";
            this.btnInsComParametros.Size = new System.Drawing.Size(246, 96);
            this.btnInsComParametros.TabIndex = 13;
            this.btnInsComParametros.Text = "Estanciar Mensalista Passando Parâmetros";
            this.btnInsComParametros.UseVisualStyleBackColor = true;
            this.btnInsComParametros.Click += new System.EventHandler(this.btnInsComParametros_Click);
            // 
            // fmrMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 481);
            this.Controls.Add(this.btnInsComParametros);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btn_EstanciaMensalista);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_DataEntrada);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_Matricula);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_SalarioMensal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_Nome);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "fmrMensalista";
            this.Text = "fmrMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_Matricula;
        private System.Windows.Forms.TextBox txt_Nome;
        private System.Windows.Forms.TextBox txt_SalarioMensal;
        private System.Windows.Forms.TextBox txt_DataEntrada;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_EstanciaMensalista;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnInsComParametros;
    }
}