﻿namespace Pclasses
{
    partial class fmrHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_EstanciarHorista = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_DataEntrada = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_Matricula = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_SalarioPorHora = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_Nome = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_NumeroDeHoras = new System.Windows.Forms.TextBox();
            this.txt_DiasDeFaltas = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_EstanciarHorista
            // 
            this.btn_EstanciarHorista.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EstanciarHorista.Location = new System.Drawing.Point(205, 348);
            this.btn_EstanciarHorista.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_EstanciarHorista.Name = "btn_EstanciarHorista";
            this.btn_EstanciarHorista.Size = new System.Drawing.Size(148, 50);
            this.btn_EstanciarHorista.TabIndex = 20;
            this.btn_EstanciarHorista.Text = "Estanciar Horista";
            this.btn_EstanciarHorista.UseVisualStyleBackColor = true;
            this.btn_EstanciarHorista.Click += new System.EventHandler(this.btn_EstanciarHorista_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(63, 203);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(212, 22);
            this.label4.TabIndex = 15;
            this.label4.Text = "Data Entrada Empresa";
            // 
            // txt_DataEntrada
            // 
            this.txt_DataEntrada.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DataEntrada.Location = new System.Drawing.Point(326, 197);
            this.txt_DataEntrada.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_DataEntrada.Name = "txt_DataEntrada";
            this.txt_DataEntrada.Size = new System.Drawing.Size(178, 28);
            this.txt_DataEntrada.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(63, 160);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(159, 22);
            this.label3.TabIndex = 14;
            this.label3.Text = "Salário Por Hora";
            // 
            // txt_Matricula
            // 
            this.txt_Matricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Matricula.Location = new System.Drawing.Point(326, 57);
            this.txt_Matricula.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Matricula.Name = "txt_Matricula";
            this.txt_Matricula.Size = new System.Drawing.Size(178, 28);
            this.txt_Matricula.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(63, 112);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 22);
            this.label2.TabIndex = 13;
            this.label2.Text = "Nome";
            // 
            // txt_SalarioPorHora
            // 
            this.txt_SalarioPorHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_SalarioPorHora.Location = new System.Drawing.Point(326, 154);
            this.txt_SalarioPorHora.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_SalarioPorHora.Name = "txt_SalarioPorHora";
            this.txt_SalarioPorHora.Size = new System.Drawing.Size(178, 28);
            this.txt_SalarioPorHora.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(63, 63);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 22);
            this.label1.TabIndex = 12;
            this.label1.Text = "Matrícula";
            // 
            // txt_Nome
            // 
            this.txt_Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Nome.Location = new System.Drawing.Point(326, 106);
            this.txt_Nome.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Nome.Name = "txt_Nome";
            this.txt_Nome.Size = new System.Drawing.Size(178, 28);
            this.txt_Nome.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(63, 253);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(166, 22);
            this.label5.TabIndex = 22;
            this.label5.Text = "Número de Horas";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(63, 296);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(139, 22);
            this.label6.TabIndex = 23;
            this.label6.Text = "Dias de Faltas";
            // 
            // txt_NumeroDeHoras
            // 
            this.txt_NumeroDeHoras.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NumeroDeHoras.Location = new System.Drawing.Point(326, 247);
            this.txt_NumeroDeHoras.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_NumeroDeHoras.Name = "txt_NumeroDeHoras";
            this.txt_NumeroDeHoras.Size = new System.Drawing.Size(178, 28);
            this.txt_NumeroDeHoras.TabIndex = 24;
            // 
            // txt_DiasDeFaltas
            // 
            this.txt_DiasDeFaltas.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DiasDeFaltas.Location = new System.Drawing.Point(326, 290);
            this.txt_DiasDeFaltas.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_DiasDeFaltas.Name = "txt_DiasDeFaltas";
            this.txt_DiasDeFaltas.Size = new System.Drawing.Size(178, 28);
            this.txt_DiasDeFaltas.TabIndex = 25;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(223, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 25);
            this.label7.TabIndex = 26;
            this.label7.Text = "HORISTA";
            // 
            // fmrHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 445);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_DiasDeFaltas);
            this.Controls.Add(this.txt_NumeroDeHoras);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btn_EstanciarHorista);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_DataEntrada);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_Matricula);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_SalarioPorHora);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_Nome);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "fmrHorista";
            this.Text = "fmrHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_EstanciarHorista;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_DataEntrada;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_Matricula;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_SalarioPorHora;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_Nome;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_NumeroDeHoras;
        private System.Windows.Forms.TextBox txt_DiasDeFaltas;
        private System.Windows.Forms.Label label7;
    }
}