﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8_Loops
{
    public partial class frmExercicio2 : Form
    {
        int num;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void txtN_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtN.Text, out num))
            {
                MessageBox.Show("Digite um número maior do que 0 (zero)!");
                txtN.Focus();
            }
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            double n_saida = 0;

            for (double i = 1; i <= num; i++)
            {
                n_saida += (1 / i);
            }

            MessageBox.Show($"Número H: {n_saida.ToString("N4")}");
        }
    }
}
