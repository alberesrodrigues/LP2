﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8_Loops
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void txtPalavra_Validated(object sender, EventArgs e)
        {
            if (txtPalavra.Text == "")
            {
                MessageBox.Show("Digite uma palavra");
                txtPalavra.Focus();
            }
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            string entrada = txtPalavra.Text.ToUpper();
            string frase = entrada.Replace(" ", "");
            char[] frase_invertida = frase.ToCharArray();
            Array.Reverse(frase_invertida);
            string frase_inv = new string(frase_invertida);
            string saida = "";
      
            if (string.CompareOrdinal(frase, frase_inv) == 0 )
            {
                saida += $"A palavra " + entrada + " é um Polindromo";
                MessageBox.Show(saida);
                txtPalavra.Focus();
            }
            else
            {
                saida += $"A palavra " + entrada + " não é um Polindromo";
                MessageBox.Show(saida);
                txtPalavra.Focus();
            }
        }
    }
}
