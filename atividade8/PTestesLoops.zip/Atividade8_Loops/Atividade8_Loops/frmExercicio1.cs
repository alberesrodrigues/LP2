﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8_Loops
{
    public partial class frmExercicio1 : Form
    {
        int qtdEspacos = 0, qtdR = 0, qtdPares = 0;
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnFor_Click(object sender, EventArgs e)
        {
            string frase = rtbxFrase.Text.ToString();
            string saida = "FOR\n";

            for (int i = 0; i < frase.Length; i++)
            {
                if (char.IsWhiteSpace(frase[i]))
                {
                    qtdEspacos++;
                }
                else if (frase[i] == 'R' || frase[i] == 'r')
                {
                    qtdR++;
                }

                if (i != (frase.Length - 1))
                {
                    if (frase[i] == frase[i + 1])
                    {
                        qtdPares++;
                    }
                }
            }

            for (int i = 0; i < 3; i++)
            {
                if (i == 0)
                {
                    saida += $"Total de Espaços em Branco: {qtdEspacos}\n";
                }
                else if (i == 1)
                {
                    saida += $"Total de Letras R: {qtdR}\n";
                }
                else
                {
                    saida += $"Total de Pares de Letras: {qtdPares}\n";
                }
            }

            MessageBox.Show(saida);
        }

        private void btnForeach_Click(object sender, EventArgs e)
        {
            string frase = rtbxFrase.Text.ToString();
            string saida = "FOREACH\n";
            int cont = 0;

            foreach (char c in frase)
            {
                if (char.IsWhiteSpace(c))
                {
                    qtdEspacos++;
                }
                else if (c == 'R' || c == 'r')
                {
                    qtdR++;
                }

                if (cont != (frase.Length - 1))
                {
                    if (c == frase[frase.IndexOf(c) + 1])
                    {
                        qtdPares++;
                    }
                }
                cont++;
            }

            for (int i = 0; i < 3; i++)
            {
                if (i == 0)
                {
                    saida += $"Total de Espaços em Branco: {qtdEspacos}\n";
                }
                else if (i == 1)
                {
                    saida += $"Total de Letras R: {qtdR}\n";
                }
                else
                {
                    saida += $"Total de Pares de Letras: {qtdPares}\n";
                }
            }

            MessageBox.Show(saida);
        }

        private void btnWhile_Click(object sender, EventArgs e)
        {
            string frase = rtbxFrase.Text.ToString();
            string saida = "WHILE\n";
            int c = 0;

            while (c < frase.Length)
            {
                if (char.IsWhiteSpace(frase[c]))
                {
                    qtdEspacos++;
                }
                else if (frase[c] == 'R' ||frase[c] == 'r')
                {
                    qtdR++;
                }

                if (c != (frase.Length - 1))
                {
                    if (frase[c] == frase[c + 1])
                    {
                        qtdPares++;
                    }
                }
                c++;
            }

            for (int i = 0; i < 3; i++)
            {
                if (i == 0)
                {
                    saida += $"Total de Espaços em Branco: {qtdEspacos}\n";
                }
                else if (i == 1)
                {
                    saida += $"Total de Letras R: {qtdR}\n";
                }
                else
                {
                    saida += $"Total de Pares de Letras: {qtdPares}\n";
                }
            }

            MessageBox.Show(saida);
        }
    }
}
