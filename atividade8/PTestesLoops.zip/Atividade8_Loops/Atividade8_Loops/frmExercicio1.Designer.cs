﻿namespace Atividade8_Loops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblFrase = new Label();
            rtbxFrase = new RichTextBox();
            btnFor = new Button();
            btnWhile = new Button();
            btnForeach = new Button();
            SuspendLayout();
            // 
            // lblFrase
            // 
            lblFrase.AutoSize = true;
            lblFrase.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblFrase.Location = new Point(134, 82);
            lblFrase.Name = "lblFrase";
            lblFrase.Size = new Size(252, 31);
            lblFrase.TabIndex = 0;
            lblFrase.Text = "Escreva sua Frase Aqui";
            // 
            // rtbxFrase
            // 
            rtbxFrase.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rtbxFrase.Location = new Point(72, 116);
            rtbxFrase.Name = "rtbxFrase";
            rtbxFrase.Size = new Size(381, 229);
            rtbxFrase.TabIndex = 1;
            rtbxFrase.Text = "";
            // 
            // btnFor
            // 
            btnFor.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnFor.Location = new Point(72, 370);
            btnFor.Name = "btnFor";
            btnFor.Size = new Size(94, 38);
            btnFor.TabIndex = 2;
            btnFor.Text = "For";
            btnFor.UseVisualStyleBackColor = true;
            btnFor.Click += btnFor_Click;
            // 
            // btnWhile
            // 
            btnWhile.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnWhile.Location = new Point(359, 370);
            btnWhile.Name = "btnWhile";
            btnWhile.Size = new Size(94, 38);
            btnWhile.TabIndex = 4;
            btnWhile.Text = "While";
            btnWhile.UseVisualStyleBackColor = true;
            btnWhile.Click += btnWhile_Click;
            // 
            // btnForeach
            // 
            btnForeach.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnForeach.Location = new Point(211, 370);
            btnForeach.Name = "btnForeach";
            btnForeach.Size = new Size(94, 38);
            btnForeach.TabIndex = 3;
            btnForeach.Text = "Foreach";
            btnForeach.UseVisualStyleBackColor = true;
            btnForeach.Click += btnForeach_Click;
            // 
            // frmExercicio1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(531, 450);
            Controls.Add(btnForeach);
            Controls.Add(btnWhile);
            Controls.Add(btnFor);
            Controls.Add(rtbxFrase);
            Controls.Add(lblFrase);
            Name = "frmExercicio1";
            Text = "frmExercicio1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblFrase;
        private RichTextBox rtbxFrase;
        private Button btnFor;
        private Button btnWhile;
        private Button btnForeach;
    }
}