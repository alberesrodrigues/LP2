﻿namespace Atividade8_Loops
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtN = new TextBox();
            lblFrase = new Label();
            btnEnter = new Button();
            SuspendLayout();
            // 
            // txtN
            // 
            txtN.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtN.Location = new Point(164, 138);
            txtN.Name = "txtN";
            txtN.Size = new Size(129, 34);
            txtN.TabIndex = 0;
            txtN.Validated += txtN_Validated;
            // 
            // lblFrase
            // 
            lblFrase.AutoSize = true;
            lblFrase.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblFrase.Location = new Point(87, 110);
            lblFrase.Name = "lblFrase";
            lblFrase.Size = new Size(291, 25);
            lblFrase.TabIndex = 1;
            lblFrase.Text = "Forneça um Número maior que 0";
            // 
            // btnEnter
            // 
            btnEnter.Location = new Point(180, 178);
            btnEnter.Name = "btnEnter";
            btnEnter.Size = new Size(94, 29);
            btnEnter.TabIndex = 2;
            btnEnter.Text = "Enter";
            btnEnter.UseVisualStyleBackColor = true;
            btnEnter.Click += btnEnter_Click;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(487, 269);
            Controls.Add(btnEnter);
            Controls.Add(lblFrase);
            Controls.Add(txtN);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtN;
        private Label lblFrase;
        private Button btnEnter;
    }
}