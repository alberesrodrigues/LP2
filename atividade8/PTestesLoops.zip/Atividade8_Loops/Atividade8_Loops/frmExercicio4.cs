﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8_Loops
{
    public partial class frmExercicio4 : Form
    {

        string nome, matricula;
        int producao;
        double salario, gratificacao;

        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void txtNome_Validated(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Nome incorreto!");
                txtNome.Focus();
            }
            else
            {
                foreach (char c in txtNome.Text)
                {
                    if (!char.IsLetter(c) && c != ' ')
                    {
                        MessageBox.Show("Nome incorreto!");
                        txtNome.Text = " ";
                        txtNome.Focus();
                    }
                    else
                    {
                        nome = txtNome.Text;
                    }
                }
            }
        }

        private void txtMatricula_Validated(object sender, EventArgs e)
        {
            if (txtMatricula.Text == "")
            {
                MessageBox.Show("Matrícula incorreta!");
                txtMatricula.Focus();
            }
            else
            {
                foreach (char c in txtMatricula.Text)
                {
                    if (!char.IsNumber(c))
                    {
                        MessageBox.Show("Matrícula incorreta!");
                        txtMatricula.Text = " ";
                        txtMatricula.Focus();
                    }
                    else
                    {
                        matricula = txtMatricula.Text;
                    }
                }
            }
        }

        private void txtProducao_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtProducao.Text, out producao))
            {
                MessageBox.Show("Digite a quantidade de Produzida!");
                txtProducao.Focus();
            }
        }

        private void mskbxSalario_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxSalario.Text, out salario))
            {
                MessageBox.Show("Digite o Salário!");
                mskbxSalario.Focus();
            }
        }

        private void mskbxGratificacao_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxGratificacao.Text, out gratificacao))
            {
                MessageBox.Show("Digite a Gratificação!");
                mskbxSalario.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double salarioBruto, b = 0, c = 0, d = 0;

            if (producao >= 150)
            {
                b = 1; c = 1; d = 1;
            }
            else if (producao >= 120)
            {
                b = 1; c = 1;
            }
            else if (producao >= 100)
            {
                b = 1;
            }

            salarioBruto = salario + (salario * (0.05 * b + 0.1 * c + 0.1 * d));

            if (salarioBruto > 7000)
            {
                if (producao < 150 && gratificacao == 0)
                {
                    salarioBruto = 7000;
                }
            }

           mskbxSalarioBruto.Text = salarioBruto.ToString("N2");
        }
    }
}
