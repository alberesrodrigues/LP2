﻿namespace Atividade8_Loops
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNome = new Label();
            lblMatricula = new Label();
            lblProducao = new Label();
            lblSalario = new Label();
            lblGratificacao = new Label();
            txtNome = new TextBox();
            txtMatricula = new TextBox();
            txtProducao = new TextBox();
            mskbxGratificacao = new MaskedTextBox();
            lblSalarioBruto = new Label();
            mskbxSalarioBruto = new MaskedTextBox();
            btnCalcular = new Button();
            mskbxSalario = new MaskedTextBox();
            SuspendLayout();
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold);
            lblNome.Location = new Point(50, 57);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(67, 25);
            lblNome.TabIndex = 0;
            lblNome.Text = "Nome:";
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold);
            lblMatricula.Location = new Point(50, 99);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(94, 25);
            lblMatricula.TabIndex = 1;
            lblMatricula.Text = "Matrícula:";
            // 
            // lblProducao
            // 
            lblProducao.AutoSize = true;
            lblProducao.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold);
            lblProducao.Location = new Point(50, 141);
            lblProducao.Name = "lblProducao";
            lblProducao.Size = new Size(95, 25);
            lblProducao.TabIndex = 2;
            lblProducao.Text = "Produção:";
            // 
            // lblSalario
            // 
            lblSalario.AutoSize = true;
            lblSalario.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold);
            lblSalario.Location = new Point(50, 181);
            lblSalario.Name = "lblSalario";
            lblSalario.Size = new Size(72, 25);
            lblSalario.TabIndex = 3;
            lblSalario.Text = "Salário:";
            // 
            // lblGratificacao
            // 
            lblGratificacao.AutoSize = true;
            lblGratificacao.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold);
            lblGratificacao.Location = new Point(50, 224);
            lblGratificacao.Name = "lblGratificacao";
            lblGratificacao.Size = new Size(113, 25);
            lblGratificacao.TabIndex = 4;
            lblGratificacao.Text = "Gratificação:";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(187, 55);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(125, 27);
            txtNome.TabIndex = 5;
            txtNome.Validated += txtNome_Validated;
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(187, 100);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(125, 27);
            txtMatricula.TabIndex = 6;
            txtMatricula.Validated += txtMatricula_Validated;
            // 
            // txtProducao
            // 
            txtProducao.Location = new Point(187, 142);
            txtProducao.Name = "txtProducao";
            txtProducao.Size = new Size(125, 27);
            txtProducao.TabIndex = 7;
            txtProducao.Validated += txtProducao_Validated;
            // 
            // mskbxGratificacao
            // 
            mskbxGratificacao.Location = new Point(187, 225);
            mskbxGratificacao.Mask = "####.00";
            mskbxGratificacao.Name = "mskbxGratificacao";
            mskbxGratificacao.Size = new Size(125, 27);
            mskbxGratificacao.TabIndex = 9;
            mskbxGratificacao.TextAlign = HorizontalAlignment.Right;
            mskbxGratificacao.Validated += mskbxGratificacao_Validated;
            // 
            // lblSalarioBruto
            // 
            lblSalarioBruto.AutoSize = true;
            lblSalarioBruto.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold);
            lblSalarioBruto.Location = new Point(50, 281);
            lblSalarioBruto.Name = "lblSalarioBruto";
            lblSalarioBruto.Size = new Size(124, 25);
            lblSalarioBruto.TabIndex = 10;
            lblSalarioBruto.Text = "Salário Bruto:";
            // 
            // mskbxSalarioBruto
            // 
            mskbxSalarioBruto.Enabled = false;
            mskbxSalarioBruto.Location = new Point(187, 282);
            mskbxSalarioBruto.Mask = "####.00";
            mskbxSalarioBruto.Name = "mskbxSalarioBruto";
            mskbxSalarioBruto.Size = new Size(125, 27);
            mskbxSalarioBruto.TabIndex = 11;
            mskbxSalarioBruto.TextAlign = HorizontalAlignment.Right;
            // 
            // btnCalcular
            // 
            btnCalcular.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCalcular.Location = new Point(187, 335);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(94, 36);
            btnCalcular.TabIndex = 12;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // mskbxSalario
            // 
            mskbxSalario.Location = new Point(187, 182);
            mskbxSalario.Mask = "####.00";
            mskbxSalario.Name = "mskbxSalario";
            mskbxSalario.Size = new Size(125, 27);
            mskbxSalario.TabIndex = 8;
            mskbxSalario.TextAlign = HorizontalAlignment.Right;
            mskbxSalario.Validated += mskbxSalario_Validated;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(471, 406);
            Controls.Add(btnCalcular);
            Controls.Add(mskbxSalarioBruto);
            Controls.Add(lblSalarioBruto);
            Controls.Add(mskbxGratificacao);
            Controls.Add(mskbxSalario);
            Controls.Add(txtProducao);
            Controls.Add(txtMatricula);
            Controls.Add(txtNome);
            Controls.Add(lblGratificacao);
            Controls.Add(lblSalario);
            Controls.Add(lblProducao);
            Controls.Add(lblMatricula);
            Controls.Add(lblNome);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNome;
        private Label lblMatricula;
        private Label lblProducao;
        private Label lblSalario;
        private Label lblGratificacao;
        private TextBox txtNome;
        private TextBox txtMatricula;
        private TextBox txtProducao;
        private MaskedTextBox mskbxGratificacao;
        private Label lblSalarioBruto;
        private MaskedTextBox mskbxSalarioBruto;
        private Button btnCalcular;
        private MaskedTextBox mskbxSalario;
    }
}