﻿namespace Atividade8_Loops
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnTestar = new Button();
            lblFrase = new Label();
            txtPalavra = new TextBox();
            SuspendLayout();
            // 
            // btnTestar
            // 
            btnTestar.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTestar.Location = new Point(201, 181);
            btnTestar.Name = "btnTestar";
            btnTestar.Size = new Size(94, 36);
            btnTestar.TabIndex = 1;
            btnTestar.Text = "Testar";
            btnTestar.UseVisualStyleBackColor = true;
            btnTestar.Click += btnTestar_Click;
            // 
            // lblFrase
            // 
            lblFrase.AutoSize = true;
            lblFrase.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblFrase.Location = new Point(165, 91);
            lblFrase.Name = "lblFrase";
            lblFrase.Size = new Size(182, 28);
            lblFrase.TabIndex = 3;
            lblFrase.Text = "Digite um Palavra";
            // 
            // txtPalavra
            // 
            txtPalavra.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtPalavra.Location = new Point(110, 122);
            txtPalavra.Name = "txtPalavra";
            txtPalavra.Size = new Size(283, 38);
            txtPalavra.TabIndex = 0;
            txtPalavra.Validated += txtPalavra_Validated;
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(541, 320);
            Controls.Add(txtPalavra);
            Controls.Add(lblFrase);
            Controls.Add(btnTestar);
            Name = "frmExercicio3";
            Text = "frmExercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnTestar;
        private Label lblFrase;
        private TextBox txtPalavra;
    }
}