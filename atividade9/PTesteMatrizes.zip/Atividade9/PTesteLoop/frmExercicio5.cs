﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteLoop
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();

            char[] validacao = new char[] { 'A', 'B', 'C', 'D', 'E' };
            char[] gabarito = new char[] { 'B', 'D', 'A', 'C', 'E',
                                           'A', 'D', 'C', 'D', 'E' };
            char[,] respostas = new char[3, 10];
            char alternativa;

            string saida;

            int totalAcertos = 0;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 10; j++) 
                {
                    char.TryParse(Interaction.InputBox($"Aluno {i + 1} - Questão {j + 1}: ",
                                 "Respostas"), out alternativa);

                    alternativa = char.ToUpper(alternativa);

                    if (validacao.Contains(alternativa))
                    {
                        respostas[i, j] = alternativa;
                    }
                    else
                    {
                        MessageBox.Show("Alternativa incorreta!");
                        j--;
                    }
                }
            }

            for (int i = 0;i < 3; i++)
            {
                totalAcertos = 0;
                lstGabaritos.Items.Add($"Aluno {i + 1}");
                for (int j = 0;j < 10; j++)
                {
                    if (respostas[i, j] == gabarito[j])
                    {
                        saida = $"Resposta: {respostas[i, j]} - Gabarito: {gabarito[j]} CERTO";
                        lstGabaritos.Items.Add(saida);
                        totalAcertos++;
                    }
                    else
                    {
                        saida = $"Resposta: {respostas[i, j]} - Gabarito: {gabarito[j]} ERRADO";
                        lstGabaritos.Items.Add(saida);
                    }
                }
                lstGabaritos.Items.Add($"Acertos: {totalAcertos}");
                lstGabaritos.Items.Add("");
                lstGabaritos.Items.Add("");
            }
        }
    }
}
